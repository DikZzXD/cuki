import asyncio
import re
from datetime import datetime, timezone
import requests
from bs4 import BeautifulSoup
from aiogram import Bot, Dispatcher, types, F
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
import html

import config
import db
UTC = timezone.utc
db.init_db()

bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

session = requests.Session()

_worker_task = None
_worker_running = False

def login_and_fetch_token():
    print("Ana ƙoƙarin shiga da karɓar sabon zaman/token...")
    try:
        r = session.get(config.LOGIN_URL, timeout=15)
        r.raise_for_status()

        soup = BeautifulSoup(r.text, 'html.parser')
        token_input = soup.find('input', {'name': '_token'})
        
        if not token_input or not token_input.get('value'):
            db.save_error("Shiga ya kasa: Ba a iya samun asalin CSRF token ba.")
            print("Shiga ya kasa: Ba a iya samun asalin CSRF token ba.")
            return False

        initial_csrf_token = token_input.get('value')
        
        login_data = {
            '_token': initial_csrf_token,
            'email': config.LOGIN_EMAIL,
            'password': config.LOGIN_PASSWORD,
            'g-recaptcha-response': '',
            'submit': 'login'
        }
        
        session.headers.update(config.HEADERS)

        r_login = session.post(config.LOGIN_URL, data=login_data, timeout=15, allow_redirects=False)

        if r_login.status_code == 302 and 'location' in r_login.headers and 'portal' in r_login.headers['location']:
            print("Shiga ya yi nasara! Yanzu za a karɓi sabon token daga shafin portal.")
            
            r_portal = session.get(r_login.headers['location'], timeout=15)
            r_portal.raise_for_status()
            
            soup_portal = BeautifulSoup(r_portal.text, 'html.parser')
            new_token_input = soup_portal.find('input', {'name': '_token'})
            
            if not new_token_input or not new_token_input.get('value'):
                db.save_error("Shiga ya yi nasara amma ba a iya samun sabon CSRF token ba.")
                print("Shiga ya yi nasara amma ba a iya samun sabon CSRF token ba.")
                return False

            config.CSRF_TOKEN = new_token_input.get('value')
            print("An sabunta cookie na zaman da CSRF token cikin nasara.")
            return True
        else:
            db.save_error(f"Buƙatar shiga ta POST ta kasa. Status code: {r_login.status_code}. Response: {r_login.text}")
            print(f"Buƙatar shiga ta POST ta kasa. Status code: {r_login.status_code}")
            return False

    except requests.exceptions.RequestException as e:
        db.save_error(f"Tsarin shiga ya kasa da wani kuskure: {e}")
        print(f"Tsarin shiga ya kasa da wani kuskure: {e}")
        return False

def mask_number(num: str) -> str:
    s = num.strip()
    if len(s) <= (config.MASK_PREFIX_LEN + config.MASK_SUFFIX_LEN):
        return s
    return s[:config.MASK_PREFIX_LEN] + "★★★★" + s[-config.MASK_SUFFIX_LEN:]

def detect_service(text: str) -> str:
    t = (text or "").lower()
    for k in sorted(config.SERVICES.keys(), key=len, reverse=True):
        if k in t:
            return config.SERVICES[k]
    if "twilio" in t:
        return "Twilio"
    return "Service"

def detect_country(number: str, extra_text: str = "") -> str:
    s = number.lstrip("+")
    for prefix, flagname in config.COUNTRY_FLAGS.items():
        if s.startswith(prefix):
            return flagname
    txt = (extra_text or "").upper()
    if "PERU" in txt:
        return config.COUNTRY_FLAGS.get("51", "🇵🇪 Peru")
    if "BANGLADESH" in txt or "+880" in number:
        return config.COUNTRY_FLAGS.get("880", "🇧🇩 Bangladesh")
    return "🌍 Unknown"

def clean_message_for_otp_extraction(message_text: str) -> str:
    cleaned_text = message_text

    # 1. Hapus semua tag HTML dan dapatkan teks murni
    if '<' in cleaned_text or '>' in cleaned_text:
        soup = BeautifulSoup(cleaned_text, 'html.parser')
        # Hapus semua script, style, meta tags
        for script_or_style in soup(["script", "style", "meta", "link"]):
            script_or_style.extract()
        
        # Coba dapatkan teks dari body, atau paragraf jika ada, jika tidak, dari seluruh soup
        body_content = soup.find('body')
        if body_content:
            cleaned_text = body_content.get_text(separator=' ', strip=True)
        else:
            p_tag = soup.find('p')
            if p_tag:
                cleaned_text = p_tag.get_text(separator=' ', strip=True)
            else:
                cleaned_text = soup.get_text(separator=' ', strip=True)
            
    # 2. Normalisasi spasi berlebihan dan trim
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()

    # 3. Hapus prefix umum yang tidak diinginkan
    prefixes_to_remove = [
        r"sms received:",
        r"message received:",
        r"<#>\s*your whatsapp business code:",
        r"<#>",
        r"otp for",
        r"code is",
        r"is:",
        r"code:",
        r"code\s*:\s*",
        r"your verification code is",
        r"verification code:",
        r"your (\w+) code is",
        r"your verification code:",
        r"your activation code is:",
        r"your (\w+) verification code is:",
        r"your login code is",
        r"your security code is",
        r"cli whatsapp message content", # Menangani "CLI WhatsApp Message Content"
        r"your whatsapp account is being registered on a new device do not share this code with anyone", # Pesan panjang WhatsApp
    ]
    for prefix_pattern in prefixes_to_remove:
        match = re.match(r"(?:\W*\b" + prefix_pattern + r"\b\W*)", cleaned_text, re.IGNORECASE)
        if match:
            cleaned_text = cleaned_text[match.end():].strip()
            
    # 4. Hapus suffix atau teks fragmen HTML yang tidak relevan (tanpa "Powered By GarskO")
    cleaned_text = re.sub(r"span\s+class=\"currency", "", cleaned_text, flags=re.IGNORECASE).strip()
    cleaned_text = re.sub(r"<span\s+class=\"currency", "", cleaned_text, flags=re.IGNORECASE).strip()
    cleaned_text = re.sub(r"class=\"currency", "", cleaned_text, flags=re.IGNORECASE).strip()
    cleaned_text = re.sub(r"cdr\">\d+\.\d+", "", cleaned_text).strip()
    
    # Hapus fragmen HTML lain yang sering muncul seperti "</div>", "</p>", dll.
    cleaned_text = re.sub(r"<\/\w+>", "", cleaned_text).strip() # Hapus tag penutup seperti </div>, </p>

    # 5. Hapus karakter non-alfanumerik atau underscore di awal/akhir yang mungkin tersisa
    cleaned_text = re.sub(r'^[\W_]+', '', cleaned_text).strip()
    cleaned_text = re.sub(r'[\W_]+$', '', cleaned_text).strip()
    
    # --- PERUBAHAN DI SINI: MENANGANI PESAN "UNPAID" ---
    # Jika pesan HANYA berisi "Unpaid" atau "UnPaid", kita kosongkan.
    # Jika ada teks lain, kita coba hapus "Unpaid" dari teks tersebut.
    if re.fullmatch(r"unpaid", cleaned_text, re.IGNORECASE):
        return "" # Jika hanya "Unpaid", kembalikan string kosong
    
    # Hapus "Unpaid" jika muncul di dalam pesan yang lebih panjang
    cleaned_text = re.sub(r"\b(?:unpaid|un Paid)\b", "", cleaned_text, flags=re.IGNORECASE).strip()
    # --- AKHIR PERUBAHAN ---

    # Akhir: Normalisasi spasi berlebihan lagi setelah semua penghapusan
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
    
    # Jika setelah semua pembersihan pesan menjadi sangat pendek (misal hanya 1-2 karakter)
    # dan terlihat seperti sampah, kita bisa menandainya sebagai kosong atau string tertentu.
    if len(cleaned_text) < 3 and not cleaned_text.isdigit(): # Jika terlalu pendek dan bukan hanya angka
        return "" # Kembalikan string kosong agar bisa dibedakan

    return cleaned_text.strip()

def extract_otps(text: str):
    # This function is no longer used to FILTER messages, but might be used internally
    # to store an OTP value in the DB, even if it's not displayed.
    text = text.strip()

    # Regex for 3 digit - 3 digit (or space)
    match_separated_otp = re.search(
        r"(?:code|is|is:?|:)?\s*(\d{3})[- ](\d{3})",
        text,
        re.IGNORECASE
    )
    if match_separated_otp:
        return [match_separated_otp.group(1) + match_separated_otp.group(2)]

    # Regex for keyword followed by 4-8 digits
    match_keyword_digits = re.search(r"(?:code|is|is:?|:)\s*(\d{4,8})\b", text, re.IGNORECASE)
    if match_keyword_digits:
        return [match_keyword_digits.group(1)]

    # Regex for alphanumeric 6-12 characters with at least one digit
    match_alphanumeric = re.search(r"\b(?=[a-zA-Z0-9]*\d)([a-zA-Z0-9]{6,12})\b", text)
    if match_alphanumeric:
        return [match_alphanumeric.group(1)]

    # Fallback for 4-8 pure digits
    matches_fallback_digits = re.findall(r"\b(\d{4,8})\b", text)
    if matches_fallback_digits:
        return matches_fallback_digits

    return []

def parse_ranges(html_text: str):
    soup = BeautifulSoup(html_text, "html.parser")
    ranges = []
    for opt in soup.select("select#range option"):
        val = opt.get_text(strip=True)
        if val:
            ranges.append(val)
    if not ranges:
        for m in re.finditer(r"([A-Z][A-Z\s]{2,}\s+\d{2,6})", html_text):
            ranges.append(m.group(1).strip())
    return list(dict.fromkeys(ranges))

def parse_numbers(html_text: str):
    soup = BeautifulSoup(html_text, "html.parser")
    nums = []
    for tr in soup.select("table tr"):
        tds = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
        for txt in tds:
            m = re.search(r"(\+?\d{6,15})", txt)
            if m:
                nums.append(m.group(1))
                break
    if not nums:
        for m in re.finditer(r"(\+?\d{6,15})", html_text):
            nums.append(m.group(1))
    return list(dict.fromkeys(nums))

def parse_messages_with_timestamps(html_text: str):
    soup = BeautifulSoup(html_text, "html.parser")
    msgs = []
    for tr in soup.select("table tbody tr"):
        tds = tr.find_all("td")
        if len(tds) >= 3:
            timestamp_str = tds[0].get_text(strip=True)
            full_msg = tds[2].get_text(strip=True)
            if timestamp_str and full_msg:
                try:
                    # Tabbatar da tsarin lokaci ya dace da abin da kuke tsammani
                    # Misali: "YYYY-MM-DD HH:MM:SS"
                    # Idan daga shafin yanar gizo yana da tsari daban, daidaita shi anan.
                    fetched_at = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S").astimezone(UTC).strftime("%Y-%m-%d %H:%M:%S %Z")
                except ValueError:
                    fetched_at = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S %Z")
                msgs.append({"message": full_msg, "fetched_at": fetched_at})
    if not msgs:
        for m in re.finditer(r"([A-Za-z0-9\W\s]{10,})", html_text):
            t = m.group(1).strip()
            # No longer checking for OTP in parse_messages_with_timestamps
            if len(t) > 5: # Basic length check to avoid very short, irrelevant strings
                msgs.append({"message": t, "fetched_at": datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S %Z")})
    return msgs

def fetch_once():
    entries = []
    try:
        r = session.post(
            config.GET_SMS_URL,
            data={
                "_token": config.CSRF_TOKEN,
                "from": datetime.now(UTC).date().isoformat(),
                "to": datetime.now(UTC).date().isoformat()
            },
            timeout=20
        )
        
        if r.status_code in (419, 403, 401):
            db.save_error(f"GET_SMS status {r.status_code} - session/token ya ƙare. Ana ƙoƙarin sake shiga...")
            if login_and_fetch_token():
                print("Sake shiga ya yi nasara. Ana sake gwadawa.")
                r = session.post(
                    config.GET_SMS_URL,
                    data={
                        "_token": config.CSRF_TOKEN,
                        "from": datetime.now(UTC).date().isoformat(),
                        "to": datetime.now(UTC).date().isoformat()
                    },
                    timeout=20
                )
            else:
                db.save_error("Sake shiga ya kasa. Za a tsallake wannan zagayen.")
                return entries

        if r.status_code != 200:
            db.save_error(f"GET_SMS status {r.status_code}")
            return entries

        ranges = parse_ranges(r.text)
        if not ranges:
            try:
                j = r.json()
                if isinstance(j, list):
                    ranges = [str(x) for x in j]
            except Exception:
                pass
        
        if not ranges:
            ranges = [""]

        for rng in ranges:
            r2 = session.post(
                config.GET_NUMBER_URL,
                data={
                    "_token": config.CSRF_TOKEN,
                    "start": datetime.now(UTC).date().isoformat(),
                    "end": datetime.now(UTC).date().isoformat(),
                    "range": rng
                },
                timeout=20
            )
            if r2.status_code != 200:
                db.save_error(f"GET_NUMBER failed for range={rng} status={r2.status_code}")
                continue

            numbers = parse_numbers(r2.text)
            if not numbers:
                try:
                    j2 = r2.json()
                    if isinstance(j2, list):
                        for item in j2:
                            if isinstance(item, dict):
                                num = item.get("Number") or item.get("number") or item.get("msisdn")
                                if num:
                                    numbers.append(str(num))
                except Exception:
                    pass

            for number in numbers:
                r3 = session.post(
                    config.GET_OTP_URL,
                    data={
                        "_token": config.CSRF_TOKEN,
                        "start": datetime.now(UTC).date().isoformat(),
                        "Number": number,
                        "Range": rng
                    },
                    timeout=20
                )
                if r3.status_code != 200:
                    db.save_error(f"GET_OTP failed number={number} range={rng} status={r3.status_code}")
                    continue

                msgs_and_times = parse_messages_with_timestamps(r3.text)
                if not msgs_and_times:
                    try:
                        j3 = r3.json()
                        if isinstance(j3, list):
                            for it in j3:
                                if isinstance(it, dict):
                                    text = it.get("sms") or it.get("message") or it.get("full")
                                    if text:
                                        msgs_and_times.append({
                                            "message": text,
                                            "fetched_at": datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S %Z")
                                        })
                    except Exception:
                        pass
                
                for item in msgs_and_times:
                    original_message = item['message']
                    fetched_at = item['fetched_at']  # UTC timestamp

                    cleaned_message_for_display = clean_message_for_otp_extraction(original_message)
                    
                    otps_found = extract_otps(cleaned_message_for_display)
                    otp_to_save = otps_found[0] if otps_found else "N/A"

                    service = detect_service(original_message)
                    country = detect_country(number, rng)
                    
                    entries.append({
                        "number": number,
                        "otp": otp_to_save,  # Simpan N/A kalau gak ada OTP
                        "full_msg": original_message,
                        "service": service,
                        "country": country,
                        "range": rng,
                        "fetched_at": fetched_at
                    })
    except Exception as e:
        db.save_error(f"fetch_once exception: {e}")
    return entries


async def forward_entry(e):
    num_display = mask_number(e["number"])
    
    original_message = e.get("full_msg", "")
    fetched_at_utc_str = e.get("fetched_at", datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S %Z"))

    try:
        dt_object = datetime.strptime(fetched_at_utc_str, "%Y-%m-%d %H:%M:%S %Z")
        display_time = dt_object.strftime("%H:%M:%S %d-%m-%Y UTC")
    except ValueError:
        display_time = "Lokacin da aka karɓa ba a sani ba"

    cleaned_message_for_display = clean_message_for_otp_extraction(original_message)
    
    if not cleaned_message_for_display:
        if original_message:
            display_text = html.escape(original_message)
        else:
            display_text = "Babu cikakken saƙo da aka samu"
    else:
        display_text = html.escape(cleaned_message_for_display)
        
    otp_code = e.get("otp", "N/A")

    # Format OTP (6 digit → XXX-XXX, 4 digit → XX-XX)
    if otp_code != "N/A" and otp_code.isdigit():
        if len(otp_code) == 6:
            otp_code = otp_code[:3] + "-" + otp_code[3:]
        elif len(otp_code) == 4:
            otp_code = otp_code[:2] + "-" + otp_code[2:]
    otp_display = f"<span class=\"tg-spoiler\">{otp_code}</span>" if otp_code != "N/A" else "N/A"

    text = (
        f"╔════════════════════════════╗\n"
        f"   🔔 <b>{e.get('service').title()} OTP Alert</b>\n"
        f"╚════════════════════════════╝\n\n"
        f"🕒 <b>Time</b>    : <code>{display_time}</code>\n"
        f"🌍 <b>Region</b>  : <code>{e.get('country')}</code>\n"
        f"📱 <b>Number</b>  : <code>{num_display}</code>\n"
        f"⚙️ <b>Service</b> : <code>{e.get('service').title()}</code>\n\n"
        f"🔑 <b>Your OTP</b> : 🔒 {otp_display}\n\n"
        f"💬 <b>Full Message</b>:\n<blockquote>{display_text}</blockquote>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"<i>✨ Powered by Janda Kembang</i>"
    )
    
    kb = types.InlineKeyboardMarkup(inline_keyboard=[
        [types.InlineKeyboardButton(text="📞 Number", url=config.CHANNEL_LINK),
         types.InlineKeyboardButton(text="🤓 Si Tamvan", url="https://t.me/lu_hytamm")]
    ])
    
    try:
        await asyncio.gather(
            bot.send_message(config.GROUP_ID, text, reply_markup=kb),
            bot.send_message(config.GROUP_ID1, text, reply_markup=kb)
        )
    except Exception as exc:
        db.save_error(f"Gabaɗayan saƙo ya kasa zuwa group: {exc}")
        try:
            await bot.send_message(config.ADMIN_ID, f"Gabaɗayan saƙo ya kasa: {exc}")
        except Exception:
            pass

async def worker():
    db.set_status("online")
    await bot.send_message(config.ADMIN_ID, "✅ Worker ya fara aiki.")
    global _worker_running
    _worker_running = True
    while _worker_running:
        entries = fetch_once()
        for e in entries:
            original_message = e["full_msg"]
            
            # Bersihkan pesan untuk perbandingan duplikasi dan tampilan
            cleaned_message_for_db = clean_message_for_otp_extraction(original_message)
            
            # Jika pesan yang sudah dibersihkan kosong, anggap itu sampah dan jangan proses lebih lanjut
            if not cleaned_message_for_db:
                print(f"Mengabaikan pesan sampah dari {e['number']}: {original_message}")
                continue

            otps_found = extract_otps(cleaned_message_for_db) # Ekstrak OTP dari pesan yang sudah bersih
            otp_to_save = otps_found[0] if otps_found else "N/A"
            
            # Periksa apakah OTP/pesan sudah ada
            # Menggunakan cleaned_message_for_db untuk otp_exists saat otp_to_save adalah "N/A"
            if not db.otp_exists(e["number"], otp_to_save, cleaned_message_for_db):
                # Simpan juga cleaned_message_for_db ke DB
                db.save_otp(e["number"], otp_to_save, original_message, cleaned_message_for_db, e["service"], e["country"]) # UBAH: tambah parameter cleaned_msg
                await forward_entry(e) # forward_entry akan menggunakan cleaned_message_for_display sendiri
        await asyncio.sleep(1)   # 1 detik sekali cek
    db.set_status("offline")
    await bot.send_message(config.ADMIN_ID, "🛑 Worker ya daina aiki.")

def stop_worker_task():
    global _worker_running, _worker_task
    if not _worker_running:
        return
    _worker_running = False
    if _worker_task and not _worker_task.done():
        _worker_task.cancel()

@dp.message(F.text == "/start")
async def cmd_start(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ Ba ka da izini.")
        return
    st = db.get_status()
    kb = types.InlineKeyboardMarkup(inline_keyboard=[
        [types.InlineKeyboardButton(text="▶️ mulai cil", callback_data="start_worker"),
         types.InlineKeyboardButton(text="⏸ mati worker", callback_data="stop_worker")],
        [types.InlineKeyboardButton(text="🧹 hpus database", callback_data="clear_db"),
         types.InlineKeyboardButton(text="❗ liat error cil", callback_data="show_errors")],
        [types.InlineKeyboardButton(text="🔄 relog", callback_data="relogin")]
    ])
    await m.answer(f"⚙️ <b>OTP Receiver</b>\nStatus: <b>{st}</b>\nStored OTPs: <b>{db.count_otps()}</b>", reply_markup=kb)

@dp.callback_query()
async def cb(q: types.CallbackQuery):
    if q.from_user.id != config.ADMIN_ID:
        await q.answer("⛔ Ba ka da izini", show_alert=True)
        return
    if q.data == "start_worker":
        global _worker_task
        if _worker_task is None or _worker_task.done():
            _worker_task = asyncio.create_task(worker())
            await q.message.answer("✅ Done Cil.")
        else:
            await q.message.answer("ℹ️ Worker yana aiki tuni.")
        await q.answer()
    elif q.data == "stop_worker":
        stop_worker_task()
        await q.message.answer("🛑 Udh cil.")
        await q.answer()
    elif q.data == "clear_db":
        db.clear_otps()
        await q.message.answer("🗑 OTP DB an share shi.")
        await q.answer()
    elif q.data == "show_errors":
        rows = db.get_errors(10)
        if not rows:
            await q.message.answer("✅ Babu kurakurai da aka rubuta.")
        else:
            text = "\n\n".join([f"{r[1]} — {r[0]}" for r in rows])
            await q.message.answer(f"<b>Kurakurai na ƙarshe</b>:\n\n{text}")
        await q.answer()
    elif q.data == "relogin":
        if login_and_fetch_token():
            await q.message.answer("✅ Sake shiga na hannu ya yi nasara!")
        else:
            await q.message.answer("❌ Sake shiga na hannu ya kasa! Duba logs.")
        await q.answer()

@dp.message(F.text == "/on")
async def cmd_on(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ Ba ka da izini.")
        return
    global _worker_task
    if _worker_task is None or _worker_task.done():
        _worker_task = asyncio.create_task(worker())
        await m.answer("✅ Worker ya fara aiki.")
    else:
        await m.answer("ℹ️ Worker yana aiki tuni.")

@dp.message(F.text == "/off")
async def cmd_off(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ Ba ka da izini.")
        return
    stop_worker_task()
    await m.answer("🛑 Worker yana tsayawa...")

@dp.message(F.text == "/status")
async def cmd_status(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ Ba ka da izini.")
        return
    await m.answer(f"📡 Status: <b>{db.get_status()}</b>\n📥 OTPs da aka ajiye: <b>{db.count_otps()}</b>")

@dp.message(F.text == "/check")
async def cmd_check(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ Ba ka da izini.")
        return
    await m.answer(f"OTPs da aka ajiye: <b>{db.count_otps()}</b>")

@dp.message(F.text == "/clear")
async def cmd_clear(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ ngakak.")
        return
    db.clear_otps()
    await m.answer("🗑 OTP DATABASE UDH DI HPUS CIL.")

@dp.message(F.text == "/errors")
async def cmd_errors(m: types.Message):
    if m.from_user.id != config.ADMIN_ID:
        await m.answer("⛔ Error, Coba Cek Console.")
        return
    rows = db.get_errors(20)
    if not rows:
        await m.answer("✅ Babu kurakurai da aka rubuta.")
    else:
        text = "\n\n".join([f"{r[1]} — {r[0]}" for r in rows])
        await m.answer(f"<b>Kurakurai na ƙarshe</b>:\n\n{text}")

async def on_startup():
    print("Ana ƙoƙarin shiga da karɓar sabon zaman/token a farkon aiki.")
    if login_and_fetch_token():
        print("Shiga na farko ya yi nasara.")
    else:
        print("Shiga na farko ya kasa. Bot bazai iya aiki yadda ya kamata ba.")
        db.save_error("Shiga na farko ya kasa. Bot bazai iya aiki yadda ya kamata ba.")

    if db.get_status() == "online":
        global _worker_task
        _worker_task = asyncio.create_task(worker())

if __name__ == "__main__":
    try:
        import logging
        logging.basicConfig(level=logging.INFO)
        dp.startup.register(on_startup)
        dp.run_polling(bot)
    except KeyboardInterrupt:
        print("Fita...")