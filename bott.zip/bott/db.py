# db.py
import sqlite3
from datetime import datetime, timedelta, timezone # Tambahkan timedelta dan timezone
from config import DB_FILE # Asumsikan DB_FILE ada di config.py

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    # otps table - KEMBALIKAN UNIQUE(number, otp)
    c.execute("""
    CREATE TABLE IF NOT EXISTS otps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        number TEXT,
        otp TEXT,
        full_msg TEXT,
        full_msg_cleaned TEXT, -- BARU: Kolom untuk menyimpan pesan yang sudah dibersihkan
        service TEXT,
        country TEXT,
        fetched_at TEXT,
        sent INTEGER DEFAULT 0,
        UNIQUE(number, otp)
    )
    """)
    # ... (sisa init_db tetap sama) ...
    # errors table
    c.execute("""
    CREATE TABLE IF NOT EXISTS errors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        err TEXT,
        created_at TEXT
    )
    """)
    # status row
    c.execute("""
    CREATE TABLE IF NOT EXISTS status (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        value TEXT
    )
    """)
    c.execute("INSERT OR IGNORE INTO status (id, value) VALUES (1, 'offline')")

    # BARU: Tabel untuk menyimpan ID grup tambahan
    c.execute("""
    CREATE TABLE IF NOT EXISTS additional_groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER UNIQUE NOT NULL
    )
    """)

    conn.commit()
    conn.close()

def save_otp(number, otp, full_msg, full_msg_cleaned, service, country): # UBAH: tambah full_msg_cleaned
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    try:
        c.execute(
            "INSERT OR IGNORE INTO otps (number, otp, full_msg, full_msg_cleaned, service, country, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?)", # UBAH: tambah full_msg_cleaned di query
            (number, otp, full_msg, full_msg_cleaned, service, country, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"))
        )
        conn.commit()
    finally:
        conn.close()

def otp_exists(number: str, otp: str, cleaned_msg_for_comparison: str) -> bool: # UBAH: nama parameter
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    if otp == "N/A":
        # Jika tidak ada OTP terdeteksi, periksa duplikasi berdasarkan
        # nomor DAN pesan *yang sudah dibersihkan* dalam 5 menit terakhir.
        # Ini untuk mencegah spam pesan non-OTP yang identik.
        five_minutes_ago = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
        c.execute(
            "SELECT 1 FROM otps WHERE number=? AND full_msg_cleaned=? AND fetched_at > ? LIMIT 1", # UBAH: full_msg_cleaned
            (number, cleaned_msg_for_comparison, five_minutes_ago)
        )
    else:
        # Jika ada OTP terdeteksi, gunakan logika lama:
        # hanya periksa nomor dan OTP. Constraint UNIQUE(number, otp) akan membantu ini.
        c.execute("SELECT 1 FROM otps WHERE number=? AND otp=? LIMIT 1", (number, otp))
    
    r = c.fetchone()
    conn.close()
    return r is not None

# Anda juga perlu mengubah definisi tabel OTPE agar ada kolom full_msg_cleaned
# ini akan kita lakukan di init_db.

def mark_sent(number, otp):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE otps SET sent=1 WHERE number=? AND otp=?", (number, otp))
    conn.commit()
    conn.close()

def clear_otps():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM otps")
    conn.commit()
    conn.close()

def count_otps():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM otps")
    n = c.fetchone()[0]
    conn.close()
    return n

def save_error(text):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("INSERT INTO errors (err, created_at) VALUES (?, ?)", (text, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    conn.close()

def get_errors(limit=10):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT err, created_at FROM errors ORDER BY id DESC LIMIT ?", (limit,))
    rows = c.fetchall()
    conn.close()
    return rows

def set_status(val):
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("UPDATE status SET value=? WHERE id=1", (val,))
    conn.commit()
    conn.close()

def get_status():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT value FROM status WHERE id=1")
    r = c.fetchone()
    conn.close()
    return r[0] if r else "offline"

# BARU: Fungsi untuk mengelola ID grup tambahan
def add_group_id(group_id: int) -> bool:
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    try:
        c.execute("INSERT INTO additional_groups (group_id) VALUES (?)", (group_id,))
        conn.commit()
        return True
    except sqlite3.IntegrityError: # Group ID already exists
        return False
    finally:
        conn.close()

def delete_group_id(group_id: int) -> bool:
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("DELETE FROM additional_groups WHERE group_id = ?", (group_id,))
    conn.commit()
    return c.rowcount > 0 # Return True if a row was deleted

def get_all_group_ids() -> list:
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("SELECT group_id FROM additional_groups")
    rows = c.fetchall()
    conn.close()
    return [row[0] for row in rows]