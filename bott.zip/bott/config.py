# JANGAN DI SEBAR YATIM HDEH
# KETAUAN? MAKLU GW ENTOD SINI HDEH

BOT_TOKEN = "8395931561:AAEYrtoshBto1EZw0SNSg4W2SKiVLco8RLY"
ADMIN_ID = 6446678808
GROUP_ID = -1002683225080
GROUP_ID1 = -1002822806611
CHANNEL_LINK = "https://t.me/+MqhDN7JZoURkYTA9"

# Telegram message formatting
PARSE_MODE = "HTML"

# ==========================================================
# IVASMS Login Credentials
# ==========================================================
LOGIN_URL = "https://www.ivasms.com/login"
LOGIN_EMAIL = "dikzxd31@gmail.com"
LOGIN_PASSWORD = "dika2007"

# IVASMS endpoints
BASE = "https://www.ivasms.com"
GET_SMS_URL = f"{BASE}/portal/sms/received/getsms"
GET_NUMBER_URL = f"{BASE}/portal/sms/received/getsms/number"
GET_OTP_URL = f"{BASE}/portal/sms/received/getsms/number/sms"

# ==========================================================
# Session and CSRF token (leave these as they are)
# ==========================================================
SESSION_COOKIE = ""
CSRF_TOKEN = ""

# Request headers (don't change unless necessary)
HEADERS = {
    "Origin": "https://www.ivasms.com",
    "Referer": "https://www.ivasms.com/portal/sms/received",
    "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36",
    "X-Requested-With": "XMLHttpRequest",
    "Accept": "application/json, text/javascript, */*; q=0.01"
}

# Polling interval (seconds)
FETCH_INTERVAL = 6

# DB file
DB_FILE = "otps_and_errors.db"

# ==========================================================
# Country and Service Mappings
# ==========================================================
COUNTRY_FLAGS = {
    "234": "🇳🇬 Nigeria",
    "880": "🇧🇩 Bangladesh",
    "51": "🇵🇪 Peru",
    "225": "🇨🇮 Ivory Coast",
    "20": "🇪🇬 Egypt",
    "255": "🇹🇿 Tanzania",
    "44": "🇬🇧 United Kingdom",
    "58": "🇻🇪 Venezuela",
    "996": "🇰🇬 Kyrgyzstan",
    "593": "🇪🇨 Ecuador",
    "591": "🇧🇴 Bolivia",
    "228": "🇹🇬 Togo",
    "221": "🇸🇳 Senegal",
    "1": "🇺🇸 United States",
    "970": "🇵🇸 Palestine",
    "98": "🇮🇷 Iran",
    "964": "🇮🇶 Iraq",
    "972": "🤓 Isriwil jir",
    "383": "🇽🇰 Kosovo",
    "212": "🇲🇦 Morocco",
    "93": "🇦🇫 Afghanistan",
    "675": "🇵🇬 Papua New Guinea",
    "94": "🇱🇰 Sri Lanka",
    "966": "🇸🇦 Saudi Arabia",
    "236": "🇨🇫 Central African Republic",
    "261": "🇲🇬 Madagascar",
    "977": "🇳🇵 Nepal",
    "967": "🇾🇪 Yemen",
    "998": "🇺🇿 Uzbekistan",
    "216": "🇹🇳 Tunisia",
    "963": "🇸🇾 Syria",
}

# Service name normalization
SERVICES = {
    "whatsapp": "WhatsApp",
    "facebook": "Facebook",
    "meta": "Facebook",
    "fb": "Facebook",
    "telegram": "Telegram",
    "google": "Google",
    "instagram": "Instagram",
    "yango": "Yango",
    "signal": "Signal",
    "snapchat": "Snapchat",
    "tiktok": "Tiktok",
    "twitter": "Twitter",
    "premierbet": "Premier Bet",
    "premier bet": "Premier Bet",
}

# Masking rule: keep first N chars then **** then last M chars
MASK_PREFIX_LEN = 6
MASK_SUFFIX_LEN = 4